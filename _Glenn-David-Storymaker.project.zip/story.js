//This script prompts user for nouns, verbs and adjectives, stores the response in a variable and concatenates the response into random non-sensical phrases.

//Declare variables
  var name;  
  var noun;
  var verb;
  var adjectiveSize;
  var adjectiveEmotion;
  var adjectiveColor;
  var adjectiveMagnitude;
  var activity; 

  var storyStart;
  var storyline1;
  var storyline2;
  var storyline3;
  var storyEnd;
  var storyComplete;

//Prompt for input and assign to variables.
noun = prompt('Gimme a noun please... \n\n  (a noun is a person, place, thing or idea)');
name = prompt('Gimme a name for our s/hero, please...');

adjectiveSize = prompt('Enter an adjective describing SIZE please...\n\n (Adjectives are words that are used to describe nouns. Remember that a noun is a person, place, thing or idea like: big, little, tiny, bigly, humongous)');

adjectiveEmotion = prompt('Gimme an EMOTION please... \n\n  (like joyful, sad, happy, confused, annoyed, puzzled)'); //emotions

adjectiveColor = prompt('Pick a COLOR please... \n\n (like yellow,green, blue,red,purple)');

adjectiveMagnitude = prompt('Enter an adjective indicating MAGNITUDE please... \n\n (i.e. loud, soft, high, low, screaming)');

activity = prompt('Enter your favorite activity please...  \n\n  (i.e. watch movies, sing, exercise, dance)');

verb = prompt('Gimme a verb please...  \n\n  (a verb is the part of speech that describes an action or occurrence or indicates a state of being like: run, think, see, listen, insist, grumble, snooze.)');

//ENABLE ONLY ONE ALERT BOX

//TYPE1 SIMPLE
  //alert("I have enough words, thanks!");

//TYPE2 FANCY alert with inline  list

  //alert("I have enough words, thanks!  \n\n The words you entered are  " + name + "  " +     noun + "  " +   verb +  "  " +   adjectiveSize +  "  " +   adjectiveEmotion +  "  " +   adjectiveColor +  "  " +   adjectiveMagnitude +  " and " +   activity); 

//TYPE3 SHOWOFF  alert with unordered list by brute force

alert("I have enough words, thanks!  \n\n The words you entered are  " + name + ", \n\n" +     noun + ", \n\n" +   verb +  ",  \n\n" +   adjectiveSize +  ",  \n\n" +   adjectiveEmotion +  ",  \n\n" +   adjectiveColor +  ",  \n\n" +   adjectiveMagnitude +  " and  \n\n" +   activity); 


//Construct storylines.
  storyStart = "There once was a " + noun + " named " + name + ".  ";

  storyline1 = name + " was a very " + adjectiveSize + ", " + adjectiveColor + " " + noun +".  ";

  storyline2 =  name + " loved to " + activity + ".  ";

  storyline3 =   "Whenever " + name + " could " + activity + ", " + name + " became " + adjectiveEmotion + ".  ";

storyEnd =  "The moral of this story is: Don't " +  verb + " and " + activity + " unless you want to " + activity + " and be "+ adjectiveMagnitude + " with " + adjectiveEmotion + " " +  adjectiveSize + " and turn " + adjectiveColor + ".  The End." ;

storyComplete =  storyStart + storyline1 + storyline2 + storyline3 + storyEnd ;

//Write Story
storyComplete = storyStart +  storyline1 +  storyline2 +  storyline3 +  storyEnd;

//Publish story.
document.write(storyComplete);